// scatter_plot.rs

use plotly::{Plot, Scatter, Layout};
use plotly::layout::Axis;
use plotly::common::{Mode, Title};
use crate::csv_reader::CsvData;

pub fn create_scatter_plot(data: &CsvData, name: &str) {
    let timestamps: Vec<String> = data.data.iter().map(|point| point.timestamp.clone()).collect();
    let parameters: Vec<f64> = data.data.iter().map(|point| point.parameter).collect();

    let trace = Scatter::new(timestamps, parameters)
        .name(name)
        .mode(Mode::Markers);

    let mut plot = Plot::new();
    plot.add_trace(trace);

    let layout = Layout::new()
        .title(Title::new("Parameter Comparison Over Time"))
        .x_axis(Axis::new().title("Timestamp".into())) // Use xaxis instead of x_axis
        .y_axis(Axis::new().title("Parameter".into())); // Use yaxis instead of y_axis

    plot.set_layout(layout);

    plot.show();
}
