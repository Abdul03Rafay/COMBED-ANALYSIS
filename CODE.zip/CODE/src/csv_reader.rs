// csv_reader.rs

use std::error::Error;
use std::fs::File;
use std::io::prelude::*;
use csv::ReaderBuilder;

#[derive(Debug)]
pub struct DataPoint {
    pub timestamp: String,
    pub parameter: f64,
}

pub struct CsvData {
    pub data: Vec<DataPoint>,
}

impl CsvData {
    pub fn from_file(file_path: &str) -> Result<CsvData, Box<dyn Error>> {
        let mut file = File::open(file_path)?;
        let mut contents = String::new();
        file.read_to_string(&mut contents)?;

        let mut csv_reader = ReaderBuilder::new().has_headers(false).from_reader(contents.as_bytes());

        let data: Result<Vec<DataPoint>, Box<dyn Error>> = csv_reader
            .records()
            .map(|record| {
                let record = record?;
                Ok(DataPoint {
                    timestamp: record[0].to_string(),
                    parameter: record[1].parse::<f64>().map_err(|e| {
                        Box::new(e) as Box<dyn Error>
                    })?,
                })
            })
            .collect();

        Ok(CsvData { data: data? })
    }
}
