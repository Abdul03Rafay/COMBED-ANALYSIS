// statistical_analysis.rs

use crate::csv_reader::CsvData;
use statrs::statistics::Statistics;

pub fn calculate_mean(data: &CsvData) -> f64 {
    let values: Vec<f64> = data.data.iter().map(|point| point.parameter).collect();
    values.mean()
}

pub fn calculate_variance(data: &CsvData) -> f64 {
    let values: Vec<f64> = data.data.iter().map(|point| point.parameter).collect();
    values.variance()
}

pub fn calculate_standard_deviation(data: &CsvData) -> f64 {
    let values: Vec<f64> = data.data.iter().map(|point| point.parameter).collect();
    values.std_dev()
}