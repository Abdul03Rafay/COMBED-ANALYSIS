// src/main.rs

// Modules
mod csv_reader;
mod graph_creator;
//mod scatter_plot;  remove comment to create scatter
mod statistical_analysis;
mod arima_module;
mod clustering;

// Modules Implementations
use csv_reader::CsvData;
use graph_creator::create_comparison_graph;
//use scatter_plot::create_scatter_plot;  remove comment to create scatter
use arima_module::perform_arima_analysis;
use clustering::kmeans_clustering;
use ndarray::Array2;

// For Network Diagram
use petgraph::dot::{Dot, Config};
use petgraph::graph::DiGraph;
use plotters::style::full_palette::BLUE;
use std::fs::File;
use std::io::Write;

// Kmeans visual
use plotters::prelude::*;

fn main() {
    // Read the first CSV file
    let csv_data1 = CsvData::from_file("Energy_A.csv").expect("Failed to read CSV file 1");

    // Read the second CSV file
    let csv_data2 = CsvData::from_file("Energy_L.csv").expect("Failed to read CSV file 2");

    // Create a comparison graph
    create_comparison_graph(&csv_data1, &csv_data2);

    // Create scatter plots for each .csv files. 
    //create_scatter_plot(&csv_data1, "Data Set 1"); remove comment to create scatter
    //create_scatter_plot(&csv_data2, "Data Set 2"); remove comment to create scatter

    // Perform statistical analysis
    let mean1 = statistical_analysis::calculate_mean(&csv_data1);
    let mean2 = statistical_analysis::calculate_mean(&csv_data2);

    let variance1 = statistical_analysis::calculate_variance(&csv_data1);
    let variance2 = statistical_analysis::calculate_variance(&csv_data2);

    let std_deviation1 = statistical_analysis::calculate_standard_deviation(&csv_data1);
    let std_deviation2 = statistical_analysis::calculate_standard_deviation(&csv_data2);

    // Print or use the calculated statistics as needed
    println!("\nMean 1: {}", mean1);
    println!("Mean 2: {}", mean2);
    println!("Variance 1: {}", variance1);
    println!("Variance 2: {}", variance2);
    println!("Standard Deviation 1: {}", std_deviation1);
    println!("Standard Deviation 2: {}\n", std_deviation2);

    // Network of structure visualization.
    
    // Once graph created use following command in terminal to view network diagram: dot -Tpng graph.dot -o graph.png

    // Define the network hierarchy
    let data = vec![
        "Main Building,Academic Block",
        "Main Building,Lecture Block",
        "Academic Block,AHU",
        "Academic Block,Elevators",
        "Academic Block,Lights",
        "Academic Block,Power",
        "Academic Block,Power Sockets",
        "Academic Block,UPS Sockets",
        "Academic Block,Floors",
        "Floors,Floor 1",
        "Floors,Floor 2",
        "Floors,Floor 3",
        "Floors,Floor 4",
        "Floors,Floor 5",
        "Lecture Block,AHU",
        "Lecture Block,Floors",
        "Floors,Floor 1",
        "Floors,Floor 2",
        "Floors,Floor 3",
    ];

    // Create a directed graph
    let mut graph = DiGraph::<&str, &str>::new();
    let mut node_indices = std::collections::HashMap::new();

    // Process the data and add edges to the graph
    for line in data {
        let nodes: Vec<&str> = line.split(',').collect();
        if nodes.len() == 2 {
            let parent = nodes[0];
            let child = nodes[1];

            let parent_index = *node_indices
                .entry(parent)
                .or_insert_with(|| graph.add_node(parent));
            let child_index = *node_indices
                .entry(child)
                .or_insert_with(|| graph.add_node(child));

            graph.add_edge(parent_index, child_index, "");
        }
    }

    // Print the DOT representation of the graph to a file
    let dot_representation = format!("{:?}", Dot::with_config(&graph, &[Config::EdgeNoLabel]));
    let mut file = File::create("graph.dot").expect("Failed to create DOT file");
    file.write_all(dot_representation.as_bytes()).expect("Failed to write to DOT file");

    println!("\nDOT file 'graph.dot' created. Visualize using Graphviz.\n");


    // ARIMA analysis on the first dataset
    let _arima_result_1 = perform_arima_analysis(
    &csv_data1.data.iter().map(|point| point.timestamp.parse::<f64>().unwrap()).collect::<Vec<_>>(),
    &csv_data1.data.iter().map(|point| point.parameter).collect::<Vec<_>>(),
    );
    //println!("ARIMA Predictions for first dataset: {:?}", arima_result_1); remove comment to view results of ARIMA

    // ARIMA analysis on the second dataset
    let _arima_result_2 = perform_arima_analysis(
        &csv_data2.data.iter().map(|point| point.timestamp.parse::<f64>().unwrap()).collect::<Vec<_>>(),
        &csv_data2.data.iter().map(|point| point.parameter).collect::<Vec<_>>(),
    );
    //println!("ARIMA Predictions for second dataset: {:?}", arima_result_2); remove comment to view results of ARIMA


    // Define num_clusters and max_iters
    let num_clusters = 10;  // can change this value
    let max_iters = 1000;   // can change this value


    // Perform k-means clustering on the first dataset
    let labels1 = kmeans_clustering(
        &Array2::from_shape_vec(
            (csv_data1.data.len(), 1),
            csv_data1.data.iter().map(|point| point.parameter).collect(),
        )
        .expect("Failed to create ndarray"),
        num_clusters,
        max_iters,
    );

    // Perform k-means clustering on the second dataset
    let labels2 = kmeans_clustering(
        &Array2::from_shape_vec(
            (csv_data2.data.len(), 1),
            csv_data2.data.iter().map(|point| point.parameter).collect(),
        )
        .expect("Failed to create ndarray"),
        num_clusters,
        max_iters,
    );

    // Visualize k-means clustering for the first dataset
    visualize_kmeans(&labels1, "K-Means Clustering - Dataset 1", num_clusters);

    // Visualize k-means clustering for the second dataset
    visualize_kmeans(&labels2, "K-Means Clustering - Dataset 2", num_clusters);

}

fn visualize_kmeans(labels: &[usize], title: &str, num_clusters: usize) {
    // Create a simple bar chart to visualize k-means clustering
    let data = labels.iter().map(|&label| label as f64).collect::<Vec<_>>();

    let root = BitMapBackend::new("kmeans_visualization.png", (800, 600)).into_drawing_area();
    root.fill(&WHITE).unwrap();

    let mut chart = ChartBuilder::on(&root)
        .caption(title, ("sans-serif", 20))
        .x_label_area_size(40)
        .y_label_area_size(40)
        .build_cartesian_2d(0..data.len() as i32, 0..num_clusters as i32)
        .unwrap();

    chart
        .configure_mesh()
        .y_labels(num_clusters)
        .draw()
        .unwrap();

    chart
        .draw_series(
            Histogram::vertical(&chart)
                .style(BLUE.mix(0.5).filled())
                .data(data.iter().cloned().enumerate().map(|(x, y)| (x as i32, y as i32))),
        )
        .unwrap();
}
