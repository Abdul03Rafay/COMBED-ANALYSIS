//clusterung.rs
use ndarray::{Array2, OwnedRepr, Axis, ArrayBase};
use rand::Rng;
use ndarray::Dim;

#[derive(Debug, Clone, Copy)]
struct Point {
    value: f64,
}

struct KMeans {
    centroids: Vec<f64>,
    clusters: Vec<Vec<f64>>,
}

impl KMeans {
    fn new(k: usize, data: &ArrayBase<OwnedRepr<f64>, Dim<[usize; 2]>>) -> KMeans {
        let mut rng = rand::thread_rng();

        // Initialize centroids within the range of the data
        let min_value = data.iter().cloned().fold(f64::INFINITY, f64::min);
        let max_value = data.iter().cloned().fold(f64::NEG_INFINITY, f64::max);

        let centroids: Vec<f64> = (0..k)
            .map(|_| rng.gen_range(min_value..max_value))
            .collect();

        let clusters: Vec<Vec<f64>> = vec![Vec::new(); k];

        KMeans { centroids, clusters }
    }
    fn assign_clusters(&mut self, data: &Array2<f64>) {
        // Clear clusters before reassignment
        self.clusters = vec![Vec::new(); self.centroids.len()];

        for &value in data.iter() {
            // Find the nearest centroid
            let nearest_centroid_index = self
                .centroids
                .iter()
                .enumerate()
                .min_by_key(|(_, &centroid)| ((value - centroid).abs() * 1000.0) as i32)
                .map(|(index, _)| index)
                .unwrap();

            // Assign the value to the cluster
            self.clusters[nearest_centroid_index].push(value);
        }
    }

    fn update_centroids(&mut self) {
        // Update centroids based on the mean of each cluster
        self.centroids = self
            .clusters
            .iter()
            .map(|cluster| {
                if !cluster.is_empty() {
                    cluster.iter().sum::<f64>() / cluster.len() as f64
                } else {
                    // If the cluster is empty, keep the centroid unchanged
                    0.0
                }
            })
            .collect();
    }

    fn run(&mut self, data: &Array2<f64>, max_iterations: usize) {
        for _ in 0..max_iterations {
            self.assign_clusters(data);
            self.update_centroids();
        }
    }
}

pub fn kmeans_clustering(data: &ArrayBase<OwnedRepr<f64>, Dim<[usize; 2]>>, num_clusters: usize, max_iters: usize) -> Vec<usize> {
    let mut kmeans = KMeans::new(num_clusters, data);
    kmeans.run(data, max_iters);

    let mut labels = Vec::with_capacity(data.len_of(Axis(0)));

    for &value in data.iter() {
        // Find the label of the cluster to which the value belongs
        let mut min_distance = f64::MAX;
        let mut cluster_label = 0;

        for (label, &centroid) in kmeans.centroids.iter().enumerate() {
            let distance = (value - centroid).abs();
            if distance < min_distance {
                min_distance = distance;
                cluster_label = label;
            }
        }

        labels.push(cluster_label);
    }

    labels
}
