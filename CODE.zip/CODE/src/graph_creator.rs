// graph_creator.rs

use plotly::{Plot, Scatter, Layout};
use plotly::layout::Axis;
use plotly::common::{Mode, Title};
use crate::csv_reader::CsvData;

pub fn create_comparison_graph(data1: &CsvData, data2: &CsvData) {
    let timestamps1: Vec<String> = data1.data.iter().map(|point| point.timestamp.clone()).collect();
    let parameters1: Vec<f64> = data1.data.iter().map(|point| point.parameter).collect();

    let timestamps2: Vec<String> = data2.data.iter().map(|point| point.timestamp.clone()).collect();
    let parameters2: Vec<f64> = data2.data.iter().map(|point| point.parameter).collect();

    let trace1 = Scatter::new(timestamps1, parameters1)
        .name("Data Set 1")
        .mode(Mode::Lines);

    let trace2 = Scatter::new(timestamps2, parameters2)
        .name("Data Set 2")
        .mode(Mode::Lines);

    let mut plot = Plot::new();
    plot.add_trace(trace1);
    plot.add_trace(trace2);

    let layout = Layout::new()
        .title(Title::new("Parameter Comparison Over Time"))
        .x_axis(Axis::new().title("Timestamp".into())) 
        .y_axis(Axis::new().title("Parameter".into())); 

    plot.set_layout(layout);

    plot.show();
}
